region              = "ap-northeast-2"
project_name        = "terraform"
vpc_cidr            = "172.16.0.0/16"
azs                 = ["ap-northeast-2a", "ap-northeast-2c"]
public_key_material = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCSjqCtpDahRe+2mCI3x/9Zk0PcJJRR9i6RDXqpEULqU1FTKmozRib4/uaG0n1pxZcl1+h4l/AbrS3ykIgKoZjkq9plQWhtEMCRDBj9iw1KVfnAlVL1vqT2zGeaWRLwsDsGjTMBq6J4EBWugG831FRCmsEULiNQbtuUDNWTCnwcFX7jA85ME07y5BCYtmPOfpnXKaE+9gwldjt8P8zPi7lDuUZmbvk/kbvRLSvAu1W4N8CWN2axbBJBYi1GyFqB7HDEZ/9ewv0ewc4MNAqUuNJDkhMP7TfBC1OLDXPxpKK0enWua+o7LlqKNwjUrGT/+421kG2HUn+9Ie0wjZipDNM7 rsa-key-20261111"
web_ami             = "ami-0131b10cfa2943e15"
openvpn_ami         = "ami-0f42c79eb0c2339c9"
db_name             = "webDB"
user_name           = "root"
db_instance_class   = "db.t3.micro"
db_engine_version   = "8.4.11"
user_data           = <<-EOT
  #!/bin/bash
  yum install -y httpd php php-mbstring php-pdo php-mysqlnd php-gd wget unzip
  wget -O /tmp/frontend_source.zip https://github.com/netidgo/aws-waf-project/raw/refs/heads/main/frontend_source.zip
  unzip -o /tmp/frontend_source.zip -d /var/www/html/
  systemctl start httpd & systemctl enable httpd
  EOT
